package moviedev;
import java.lang.*;
import java.io.*;
import java.util.*;


//external class of movie type to store data from both files merged
public class Movie{
	String name = null;
	String Director = null;
	int year = 0;
	String genre = null;
	String[] Actors = null;
	float rating = 0;
	
}
