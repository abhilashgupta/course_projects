**************************README**********************************
Roll No: 110050058

Since no name has been specified for the main class file to execute the assignment,
I have named the class Moviedetails.
the only file required for the execution is Moviedetails.java which stores the values combined
from both csv files into a hashmap and thenquery through it using entryset

Therefore for compilation, the following commands will suffice:
javac Moviedetails.java
java Moviedetails

Assumptions:
Like the testcases given to us, I have assumed That the two csv files to be used,
one for details and other for ratings, will have same number of entries and they would be ordered
in the same order in both the files by their movie names.
If not, this code can be tweaked for proper storage in the hashmap by running a linear search.
Since nothing was told, I took the liberty of taking this assumption.
Also,in some cases, there is a space in between the previous comma and the entry in the csv files.
Which i have removed while storing and hence while checking, we have to ensure that
there is only a single space between the query type(q1/q2/q3) and the ocrresponsing query
Also if any of the csv files doesn't have a entry, then also it should cause no problems 
except for numerical comparisons as hashmaps include "null" by default whereever an entry is missing

I, also, hereby state that all of hte work is completely done by me solely.

References:
http://www.tutorialspoint.com/java
http://stackoverflow.com
http://www.vogella.com/articles/JavaRegularExpressions/article.html
http://javarevisited.blogspot.in
http://docs.oracle.com/javase/7/docs/api/
